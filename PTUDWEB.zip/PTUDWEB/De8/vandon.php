<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<title>Tạo mới vận đơn</title>
</head>
<?php 
	function getDataFromDB($hostName, $dbName, $userName, $pass, $query)
	{
		$connect = mysqli_connect($hostName, $userName, $pass, $dbName);
	
		if(!$connect) {
				echo 'Connect DB Error!';
		}else {
			$result = mysqli_query($connect, $query);
			$output = array();
			if(mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_array($result))
				{
					$output[$row['id']] = array();
					foreach ($row as $key => $value) {
						if(is_string($key)) {
							$output[$row['id']][$key] = $row[$key];
						}
					}
				}
				$connect->close();
				return $output;
			}
		}
	}

	$allNV = getDataFromDB('localhost', 'ontap', 'student', '123456', 'SELECT * FROM nhanvien');
	$allHH = getDataFromDB('localhost', 'ontap', 'student', '123456', 'SELECT * FROM hanghoa');

?>
<body>
	<div class="container">
		<h1 class="text-center">Thêm mới vận đơn</h1>
		<form method="POST" action="./addvandon.php" enctype="multipart/form-data">
			<fieldset class="form-group">
				<label>Người nhận</label>
				<input name="nguoinhan" type="text" class="form-control" placeholder="Người nhận">
			</fieldset>
			<fieldset class="form-group">
				<label>Trạng thái</label>
				<select name="trangthai" class="form-control">
					<option value="0">Đã giao</option>
					<option value="1">Chưa giao</option>
				</select>
			</fieldset>
			<fieldset class="form-group">
				<label>Tên nhân viên</label>
				<select name="nhanvien_id" class="form-control">
					<?php foreach ($allNV as $value): ?>
						<option value="<?= $value['id'] ?>"><?= $value['hovaten'] ?></option>
					<?php endforeach ?>
				</select>
			</fieldset>
			<fieldset class="form-group">
				<label>Hàng hóa</label>
				<select name="hanghoa_id" class="form-control">
					<?php foreach ($allHH as $value): ?>
						<option value="<?= $value['id'] ?>"><?= $value['ten'] ?></option>
					<?php endforeach ?>
				</select>
			</fieldset>
			<fieldset class="form-group">
				<label>Điện thoại</label>
				<input name="dienthoai" type="number" class="form-control" placeholder="Điện thoại">
			</fieldset>
			<fieldset class="form-group">
				<label>Địa chỉ</label>
				<input name="diachi" type="text" class="form-control" placeholder="Địa chỉ">
			</fieldset>
			<fieldset class="form-group">
				<label>Ngày giao hàng</label>
				<input name="ngaygiaohang" type="datetime-local" class="form-control" placeholder="Ngày giao hàng">
			</fieldset>
			<fieldset class="form-group">
				<label>Ghi chú</label>
				<input name="ghichu" type="text" class="form-control" placeholder="Ghi chú">
			</fieldset>
			<fieldset class="form-group">
				<label>Số lượng</label>
				<input name="soluong" type="text" class="form-control" placeholder="Số lượng">
			</fieldset>
			<button type="submit" class="btn btn-success form-control">Thêm</button>
		</form>
	</div>
</body>
</html>