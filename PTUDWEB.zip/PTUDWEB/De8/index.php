<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<title>Trang chủ</title>
</head>
<?php 
	session_start();
	if(! isset($_SESSION['tendaydu'])) {
		header("location:login.php");
	}
?>
<?php 
	
	function getDataFromDB($hostName, $dbName, $userName, $pass, $query)
	{
		$connect = mysqli_connect($hostName, $userName, $pass, $dbName);
	
		if(!$connect) {
				echo 'Connect DB Error!';
		}else {
			$result = mysqli_query($connect, $query);
			$output = array();
			if(mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_array($result))
				{
					$output[$row['id']] = array();
					foreach ($row as $key => $value) {
						if(is_string($key)) {
							$output[$row['id']][$key] = $row[$key];
						}
					}
				}
				$connect->close();
				return $output;
			}
		}
	}

	$allVanDon = getDataFromDB('localhost', 'ontap', 'student', '123456', 'SELECT * FROM vandon_view');

	
?>

<body>
	<div class="header">
		<nav class="nav">
			<a class="nav-link active" href="#">Trang chủ</a>
			<a class="nav-link" href="./vandon.php">Tạo mới</a>
			<a class="nav-link" href="./login.php">Đăng xuất</a>
			<a class="nav-link" href="#">Ảnh câu 1</a>
		</nav>
		<div class="container">
			<h1 class="text-center text-uppercase">Ứng dụng quản lí vận đơn</h1>
		</div>
	</div>

	<div class="content">
		<h2 class="text-center">Danh sách vận đơn</h2>
		<div class="container d-flex justify-content-between">
			<input id="search" type="" name="" style="width: 80%;" placeholder="Tìm kiếm....">
			<a href="./vandon.php" class="btn btn-success">Thêm mới</a>
		</div>
		
		<table class="table table-hover mt-2" style="width: 98%!important; margin: auto;">
			<thead class="thead-dark">
				<tr>
					<th>ID</th>
					<th>Tên nhân viên</th>
					<th>Trạng thái</th>
					<th>Người nhận</th>
					<th>Điện thoại</th>
					<th>Địa chỉ</th>
					<th>Ngày giao hàng</th>
					<th>Ghi chú</th>
				</tr>
			</thead>
			<tbody id="search-container">
				<?php foreach ($allVanDon as $value): ?>
					<tr>
						<td class="search-item" hidden><?= $value['hovaten'] ?></td>
						<td><?= $value['id'] ?></td>
						<td><?= $value['hovaten'] ?></td>
						<td><?= $value['trangthai'] == '1' ? 'Đã giao' : 'Chưa giao' ?></td>
						<td><?= $value['nguoinhan'] ?></td>
						<td><?= $value['dienthoai'] ?></td>
						<td><?= $value['diachi'] ?></td>
						<td><?= date("Y/m/d H:i:s", strtotime($value['ngaygiaohang']))?></td>
						<td><?= $value['ghichu'] ?></td>
					</tr>	
				<?php endforeach ?>
			</tbody>
		</table>

	</div>

	<div class="footer d-flex align-items-center justify-content-center fixed-bottom text-uppercase" style="background-color: blue">
			<h1 class="text-center m-0 text-white">Hồ Thị Thu Thủy - 85107 - CNT60ĐH - <?= date("Y:m:d") ?></h1>
	</div>
</body>
<script>
	$(document).ready(function() {
		$('body').on('keyup', '#search', function(event) {
			event.preventDefault();
			var searchKey = $(this).val();
			$("#search-container").children('tr').each((i, e) => {
				var textItem = $(e).children('.search-item').text().toLowerCase().trim();
				if(!textItem.includes(searchKey.toLowerCase())) {
					$(e).hide();
				}else {
					$(e).show();
				}
				if(searchKey == ""){
					$(e).show();
				}
			});
		});
	});
</script>
</html>