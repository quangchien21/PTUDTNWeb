<?php 
	$connect = mysqli_connect('localhost', 'student', '123456', 'ontap');
	
	if(! $connect) {
		echo 'Kết nối thất bại';
	}else {
		$nguoinhan = $_POST['nguoinhan'];
		$trangthai = $_POST['trangthai'];
		$nhanvien_id = $_POST['nhanvien_id'];
		$hanghoa_id = $_POST['hanghoa_id'];
		$dienthoai = $_POST['dienthoai'];
		$diachi = $_POST['diachi'];
		$ngaygiaohang = date("Y-m-d H:i:s", strtotime($_POST['ngaygiaohang']));
		$ghichu = $_POST['ghichu'];
		$soluong = $_POST['soluong'];
	
		$queryAddVanDon = "INSERT INTO vandon (id, nhanvien_id, trangthai, nguoinhan, dienthoai, diachi, ngaygiaohang, ghichu) VALUES (NULL, '$nhanvien_id', '$trangthai', '$nguoinhan', '$dienthoai', '$diachi', '$ngaygiaohang', '$ghichu')";

		if(mysqli_query($connect, $queryAddVanDon)) {
			$getIdVanDonQuery = "SELECT MAX(vandon.id) as max FROM vandon";
			$idVanDon = mysqli_query($connect, $getIdVanDonQuery);
			while($row = mysqli_fetch_array($idVanDon))
			{
				$result = $row['max'];
				$queryAddHangHoa = "INSERT INTO chitietvandon (id, vandon_id, hanghoa_id, soluong) VALUES (NULL, '$result', '$hanghoa_id', '$soluong')";
				if(mysqli_query($connect, $queryAddHangHoa)) {
					header("location:index.php");
				}
			}
		}
	}

?>