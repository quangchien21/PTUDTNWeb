<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="bootstrap.min.css">
	<title>Quản lí hoạt động</title>
</head>
<?php 
	function getDataFromDB($hostName, $dbName, $userName, $pass, $query)
	{
		$connect = mysqli_connect($hostName, $userName, $pass, $dbName);
	
		if(!$connect) {
				echo 'Connect DB Error!';
		}else {
			$result = mysqli_query($connect, $query);
			$output = array();
			if(mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_array($result))
				{
					$output[$row['id']] = array();
					foreach ($row as $key => $value) {
						if(is_string($key)) {
							$output[$row['id']][$key] = $row[$key];
						}
					}
				}
				$connect->close();
				return $output;
			}
		}
	}

	$clbtochuc_id = $_GET['clbtochuc_id'];

	$allHD = getDataFromDB('localhost', 'clb', 'student', '123456', "SELECT * FROM hoatdong WHERE clbtochuc_id = '$clbtochuc_id'");
?>
<body>
	<div class="container">
		<h1 class="text-center">Thêm hoạt động</h1>
		<form method="POST" action="./addhoatdong.php" enctype="multipart/form-data">
			<input name="clbtochuc_id" type="text" class="form-control" value="<?= $clbtochuc_id ?>" hidden>
			<fieldset class="form-group">
				<label>Từ ngày</label>
				<input name="tungay" type="date" class="form-control" placeholder="Value">
			</fieldset>
			<fieldset class="form-group">
				<label>Đến ngày</label>
				<input name="denngay" type="date" class="form-control" placeholder="Value">
			</fieldset>
			<fieldset class="form-group">
				<label>Mục tiêu</label>
				<textarea name="muctieu" type="date" class="form-control" placeholder="Mục tiêu"></textarea>
			</fieldset>
			<button type="submit" class="btn btn-success form-control">Thêm hoạt động</button>
		</form>
	</div>
	<br>
	<div class="container">
		<h1 class="text-center">Danh sách hoạt động</h1>
		
		<table class="table table-hover mt-2" style="width: 98%!important; margin: auto;">
			<thead class="thead-dark">
				<tr>
					<th>STT</th>
					<th>Từ ngày</th>
					<th>Đến ngày</th>
					<th>Mục tiêu</th>
				</tr>
			</thead>
			<tbody id="search-container">
				<?php $stt = 1; ?>
				<?php foreach ($allHD as $value): ?>
					<tr>
						<td><?= $stt ?></td>
						<td><?= $value['tungay'] ?></td>
						<td><?= $value['denngay'] ?></td>
						<td><?= $value['muctieu'] ?></td>
						<?php $stt++; ?>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
		<br>
		<a href="./index.php" class="btn btn-success float-right">Thoát</a>
	</div>
</body>
</html>