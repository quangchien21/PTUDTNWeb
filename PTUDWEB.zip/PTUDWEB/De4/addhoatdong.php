<?php 

	$connect = mysqli_connect('localhost', 'student', '123456', 'clb');
	
	if(! $connect) {
		echo 'Kết nối thất bại';
	}else {
		$clbtochuc_id = $_POST['clbtochuc_id'];
		$tungay = date('Y-m-d', strtotime($_POST['tungay']));
		$denngay =  date('Y-m-d', strtotime($_POST['denngay']));
		$muctieu = $_POST['muctieu'];
	
		$query = "INSERT INTO hoatdong (id, clbtochuc_id, tungay, denngay, muctieu) VALUES (NULL, '$clbtochuc_id', '$tungay', '$denngay', '$muctieu')";
	
		if(mysqli_query($connect, $query)) {
			header("location:hoatdong.php?clbtochuc_id=" .$clbtochuc_id);
		}
	}

?>