-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th1 08, 2022 lúc 04:58 PM
-- Phiên bản máy phục vụ: 10.4.22-MariaDB
-- Phiên bản PHP: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `clb`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `caulacbo`
--

CREATE TABLE `caulacbo` (
  `id` int(11) NOT NULL,
  `namthanhlap` int(11) NOT NULL,
  `ten` varchar(255) NOT NULL,
  `muctieu` text NOT NULL,
  `chutich_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `caulacbo`
--

INSERT INTO `caulacbo` (`id`, `namthanhlap`, `ten`, `muctieu`, `chutich_id`) VALUES
(2, 2011, 'CLB LL', 'Không', 1),
(3, 2112, 'CLB Đạt dẹp trai', 'Đạt đẹp trai', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chitiethoatdong`
--

CREATE TABLE `chitiethoatdong` (
  `id` int(11) NOT NULL,
  `hoatdong_id` int(11) NOT NULL,
  `sinhvien_id` int(11) NOT NULL,
  `nhiemvu` varchar(255) NOT NULL,
  `nhanxet` text NOT NULL,
  `diemdanhgia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Cấu trúc đóng vai cho view `clb_view`
-- (See below for the actual view)
--
CREATE TABLE `clb_view` (
`id` int(11)
,`namthanhlap` int(11)
,`ten` varchar(255)
,`muctieu` text
,`chutich_id` int(11)
,`hovaten` varchar(255)
);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `dangkithanhvien`
--

CREATE TABLE `dangkithanhvien` (
  `id` int(11) NOT NULL,
  `sinhvien_id` int(11) NOT NULL,
  `clb_id` int(11) NOT NULL,
  `ngaydangki` datetime NOT NULL,
  `ngayxetduyet` datetime NOT NULL,
  `chutichclb_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `dangkithanhvien`
--

INSERT INTO `dangkithanhvien` (`id`, `sinhvien_id`, `clb_id`, `ngaydangki`, `ngayxetduyet`, `chutichclb_id`) VALUES
(1, 1, 2, '2022-01-28 21:09:02', '2022-01-24 21:09:02', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hoatdong`
--

CREATE TABLE `hoatdong` (
  `id` int(11) NOT NULL,
  `clbtochuc_id` int(11) NOT NULL,
  `tungay` date NOT NULL,
  `denngay` date NOT NULL,
  `muctieu` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `hoatdong`
--

INSERT INTO `hoatdong` (`id`, `clbtochuc_id`, `tungay`, `denngay`, `muctieu`) VALUES
(1, 2, '2022-01-12', '2022-01-13', 'Mục tiêu này'),
(3, 2, '2022-01-20', '2022-01-20', 'Ăn cơm'),
(4, 3, '2022-01-22', '2022-01-20', 'Đẹp trai');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sinhvien`
--

CREATE TABLE `sinhvien` (
  `id` int(11) NOT NULL,
  `trangthai` int(11) NOT NULL,
  `hovaten` varchar(255) NOT NULL,
  `ngaysinh` date NOT NULL,
  `mota` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `sinhvien`
--

INSERT INTO `sinhvien` (`id`, `trangthai`, `hovaten`, `ngaysinh`, `mota`) VALUES
(1, 1, 'Lương Đạt', '2022-01-11', 'Không');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `username` varchar(255) NOT NULL,
  `matkhau` varchar(255) NOT NULL,
  `tendaydu` varchar(255) NOT NULL,
  `quyenhan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`username`, `matkhau`, `tendaydu`, `quyenhan`) VALUES
('admin', 'admin', 'Lương Đạt', 1);

-- --------------------------------------------------------

--
-- Cấu trúc cho view `clb_view`
--
DROP TABLE IF EXISTS `clb_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `clb_view`  AS SELECT `caulacbo`.`id` AS `id`, `caulacbo`.`namthanhlap` AS `namthanhlap`, `caulacbo`.`ten` AS `ten`, `caulacbo`.`muctieu` AS `muctieu`, `caulacbo`.`chutich_id` AS `chutich_id`, `sinhvien`.`hovaten` AS `hovaten` FROM (`caulacbo` join `sinhvien` on(`caulacbo`.`chutich_id` = `sinhvien`.`id`)) ;

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `caulacbo`
--
ALTER TABLE `caulacbo`
  ADD PRIMARY KEY (`id`),
  ADD KEY `chutich_id` (`chutich_id`);

--
-- Chỉ mục cho bảng `chitiethoatdong`
--
ALTER TABLE `chitiethoatdong`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sinhvien_id` (`sinhvien_id`),
  ADD KEY `hoatdong_id` (`hoatdong_id`);

--
-- Chỉ mục cho bảng `dangkithanhvien`
--
ALTER TABLE `dangkithanhvien`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sinhvien_id` (`sinhvien_id`),
  ADD KEY `chutichclb_id` (`chutichclb_id`),
  ADD KEY `clb_id` (`clb_id`);

--
-- Chỉ mục cho bảng `hoatdong`
--
ALTER TABLE `hoatdong`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clbtochuc_id` (`clbtochuc_id`);

--
-- Chỉ mục cho bảng `sinhvien`
--
ALTER TABLE `sinhvien`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `caulacbo`
--
ALTER TABLE `caulacbo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `chitiethoatdong`
--
ALTER TABLE `chitiethoatdong`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT cho bảng `dangkithanhvien`
--
ALTER TABLE `dangkithanhvien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT cho bảng `hoatdong`
--
ALTER TABLE `hoatdong`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `sinhvien`
--
ALTER TABLE `sinhvien`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `caulacbo`
--
ALTER TABLE `caulacbo`
  ADD CONSTRAINT `caulacbo_ibfk_1` FOREIGN KEY (`chutich_id`) REFERENCES `sinhvien` (`id`);

--
-- Các ràng buộc cho bảng `chitiethoatdong`
--
ALTER TABLE `chitiethoatdong`
  ADD CONSTRAINT `chitiethoatdong_ibfk_1` FOREIGN KEY (`sinhvien_id`) REFERENCES `sinhvien` (`id`),
  ADD CONSTRAINT `chitiethoatdong_ibfk_2` FOREIGN KEY (`hoatdong_id`) REFERENCES `hoatdong` (`id`);

--
-- Các ràng buộc cho bảng `dangkithanhvien`
--
ALTER TABLE `dangkithanhvien`
  ADD CONSTRAINT `dangkithanhvien_ibfk_1` FOREIGN KEY (`sinhvien_id`) REFERENCES `sinhvien` (`id`),
  ADD CONSTRAINT `dangkithanhvien_ibfk_2` FOREIGN KEY (`chutichclb_id`) REFERENCES `sinhvien` (`id`),
  ADD CONSTRAINT `dangkithanhvien_ibfk_3` FOREIGN KEY (`clb_id`) REFERENCES `caulacbo` (`id`);

--
-- Các ràng buộc cho bảng `hoatdong`
--
ALTER TABLE `hoatdong`
  ADD CONSTRAINT `hoatdong_ibfk_1` FOREIGN KEY (`clbtochuc_id`) REFERENCES `caulacbo` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
