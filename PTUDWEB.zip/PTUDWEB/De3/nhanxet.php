<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">
	<title>Nhận xét</title>
</head>
<?php 

	function getDataFromDB($hostName, $dbName, $userName, $pass, $query)
	{
		$connect = mysqli_connect($hostName, $userName, $pass, $dbName);
	
		if(!$connect) {
				echo 'Connect DB Error!';
		}else {
			$result = mysqli_query($connect, $query);
			$output = array();
			if(mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_array($result))
				{
					$output[$row['id']] = array();
					foreach ($row as $key => $value) {
						if(is_string($key)) {
							$output[$row['id']][$key] = $row[$key];
						}
					}
				}
				$connect->close();
				return $output;
			}
		}
	}

	$hocsinh_id = $_GET['hocsinh_id'];

	$allNX = getDataFromDB('localhost', 'thcs', 'student', '123456', "SELECT * FROM tongketnam WHERE hocsinh_id = '$hocsinh_id'");
?>
<body>
	<div class="container">
		<h1 class="text-center">Thêm mới nhận xét</h1>
		<form method="POST" action="addnhanxet.php" enctype="multipart/form-data">
			<input name="hocsinh_id" type="number" class="form-control" value="<?= $hocsinh_id ?>" hidden>
			<fieldset class="form-group">
				<label>Năm học</label>
				<input name="namhoc" type="number" class="form-control" placeholder="Năm học">
			</fieldset>
			<fieldset class="form-group">
				<label>Nhận xét chung</label>
				<textarea name="nhanxetchung" type="text" class="form-control" placeholder="Nhận xét chung"></textarea>
			</fieldset>
			<fieldset class="form-group">
				<label>Ưu điểm</label>
				<textarea name="uudiem" type="text" class="form-control" placeholder="Ưu điểm"></textarea>
			</fieldset>
			<fieldset class="form-group">
				<label>Cần khắc phục</label>
				<textarea name="cankhacphuc" type="text" class="form-control" placeholder="Cần khắc phục"></textarea>
			</fieldset>
			<fieldset class="form-group">
				<label>Được lên lớp</label>
				<select name="duoclenlop" class="form-control">
					<option value="0">Có</option>
					<option value="1">Không</option>
				</select>
			</fieldset>
			<button type="submit" class="btn btn-success form-control">Submit</button>
		</form>
	</div>
	<br>
	<div class="container">
		<h1 class="text-center">Danh sách các nhận xét</h1>
		<table class="table table-hover mt-2" style="width: 98%!important; margin: auto;">
			<thead class="thead-dark">
				<tr>
					<th>STT</th>
					<th>Năm học</th>
					<th>Nhận xét chung</th>
					<th>Ưu điểm</th>
					<th>Cần khắc phục</th>
				</tr>
			</thead>
			<tbody id="search-container">
				<?php $stt = 1; ?>
				<?php foreach ($allNX as $value): ?>
					<tr>
						<td><?= $stt ?></td>
						<td><?= $value['namhoc'] ?></td>
						<td><?= $value['nhanxetchung'] ?></td>
						<td><?= $value['uudiem'] ?></td>
						<td><?= $value['cankhacphuc'] ?></td>
					</tr>	
				<?php endforeach ?>
			</tbody>
		</table>
		<br>
		<a href="./index.php" class="btn btn-success float-right">Thoát</a>
	</div>
	
</body>
</html>