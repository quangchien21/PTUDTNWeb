<?php 
	$connect = mysqli_connect('localhost', 'student', '123456', 'thcs');

	if(! $connect) {
		echo 'Kết nối thất bại';
	}else {
		$hocsinh_id = $_POST['hocsinh_id'];
		$namhoc = $_POST['namhoc'];
		$nhanxetchung = $_POST['nhanxetchung'];
		$uudiem = $_POST['uudiem'];
		$cankhacphuc = $_POST['cankhacphuc'];
		$duoclenlop = $_POST['duoclenlop'];

		$query = "INSERT INTO tongketnam (id, hocsinh_id, namhoc, nhanxetchung, uudiem, cankhacphuc, duoclenlop) VALUES (NULL, '$hocsinh_id', '$namhoc', '$nhanxetchung', '$uudiem', '$cankhacphuc', '$duoclenlop')";

		if(mysqli_query($connect, $query)) {
			header("location:nhanxet.php?hocsinh_id=" .$hocsinh_id);
		}
	}
?>