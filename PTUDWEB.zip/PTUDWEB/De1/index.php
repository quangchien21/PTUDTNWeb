<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<title>Trang chủ</title>
</head>
<?php 
	session_start();
	if(isset($_SESSION['tendaydu'])) {
		
	}else {
		header("location:login.php");
	}
?>
<?php 
	function getDataFromDB($hostName, $dbName, $userName, $pass, $query)
	{
		$connect = mysqli_connect($hostName, $userName, $pass, $dbName);

		if(!$connect) {
				echo 'Connect DB Error!';
		}else {
			$result = mysqli_query($connect, $query);
			$output = array();
			if(mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_array($result))
				{
					$output[$row['id']] = array();
					foreach ($row as $key => $value) {
						if(is_string($key)) {
							$output[$row['id']][$key] = $row[$key];
						}
					}
				}
				$connect->close();
				return $output;
			}
		}
	}

	$donhang = getDataFromDB("localhost", "banhang", "student", "123456", "SELECT * from donhang_view");
	
?>
<body>
	<!-- Header -->
	<div class="header">
		<nav class="nav">
			<a class="nav-link active" href="#">Trang chủ</a>
			<a class="nav-link" href="./add.php">Tạo mới đơn hàng</a>
			<a class="nav-link" href="./login.php">Đăng xuất</a>
			<a class="nav-link" href="./thuy1.PNG">Ảnh câu 1</a>
		</nav>
		<div class="container">
			<h1 class="text-center text-uppercase">Ứng dụng quản lí bán hàng</h1>
		</div>
	</div>
	<!-- Content -->
	<div class="content mt-5">
		<div class="container">
			<h2 class="text-center">Danh sách vận đơn</h2>
		</div>

		<div class="container d-flex justify-content-between">
			<input id="search" type="" name="" style="width: 80%;" placeholder="Tìm kiếm vận đơn....">
			<a href="./add.php" class="btn btn-success">Thêm mới vận đơn</a>
		</div>
		
		<table class="table table-hover mt-2" style="width: 98%!important; margin: auto;">
			<thead class="thead-dark">
				<tr>
					<th>ID</th>
					<th>Khách hàng</th>
					<th>Trạng thái</th>
					<th>Khuyến mại</th>
					<th>Ngày bán</th>
					<th>Ngày giao hàng</th>
					<th>Ghi chú</th>
				</tr>
			</thead>
			<tbody id="search-container">
				<?php foreach ($donhang as $value): ?>
					<tr>
						<td class="search-item" hidden><?= $value['id'] ?></td>
						<td>#<?= $value['id'] ?></td>
						<td><?= $value['hovaten'] ?></td>
						<td><?= $value['trangthai'] == '1' ? 'Đã giao' : 'Chưa giao' ?></td>
						<td><?= $value['khuyenmai'] ?>%</td>
						<td><?= date('Y/m/d', strtotime($value['ngayban'])) ?></td>
						<td><?= date('Y/m/d', strtotime($value['ngaygiaohang'])) ?></td>
						<td><?= $value['ghichu'] ?></td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>

	</div>
	<!-- Footer -->
	<div class="footer d-flex align-items-center justify-content-center fixed-bottom text-uppercase" style="background-color: blue">
		<h1 class="text-center m-0 text-white">Hồ Thị Thu Thủy - 85107 - CNT60ĐH</h1>
	</div>
</body>
	<script>
		$(document).ready(function() {
			$('body').on('keyup', '#search', function(event) {
				event.preventDefault();
				var searchKey = $(this).val();
				$("#search-container").children('tr').each((i, e) => {
					if($(e).children('.search-item').text() != searchKey) {
						$(e).hide();
					}else {
						$(e).show();
					}
					if(searchKey == ""){
						$(e).show();
					}
				});
			});
		});
	</script>
</html>