<?php 
	$connect = mysqli_connect('localhost', 'student', '123456', 'nhansu');

	if(! $connect) {
		echo 'Kết nối thất bại';
	}else {
		$nhansu_id = $_POST['nhansu_id'];
		$ten = $_POST['ten'];
		$quanhe = $_POST['quanhe'];
		$dienthoai = $_POST['dienthoai'];

		$query = "INSERT INTO thannhan (id, nhansu_id, ten, quanhe, dienthoai) VALUES (NULL, '$nhansu_id', '$ten', '$quanhe', '$dienthoai')";

		if(mysqli_query($connect, $query)) {
			header("location:thannhan.php?nhansu_id=" .$nhansu_id);
		}
	}
?>