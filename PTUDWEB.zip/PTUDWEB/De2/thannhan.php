<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<title>Quản lí thân nhân</title>
</head>
<?php
	function getDataFromDB($hostName, $dbName, $userName, $pass, $query)
	{
		$connect = mysqli_connect($hostName, $userName, $pass, $dbName);
	
		if(!$connect) {
				echo 'Connect DB Error!';
		}else {
			$result = mysqli_query($connect, $query);
			$output = array();
			if(mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_array($result))
				{
					$output[$row['id']] = array();
					foreach ($row as $key => $value) {
						if(is_string($key)) {
							$output[$row['id']][$key] = $row[$key];
						}
					}
				}
				$connect->close();
				return $output;
			}
		}
	}
	$nhansu_id = $_GET['nhansu_id'];

	$nhanSu = getDataFromDB('localhost', 'nhansu', 'student', '123456', "SELECT * FROM nhansu WHERE id='$nhansu_id'");
	$allThanNhan = getDataFromDB('localhost', 'nhansu', 'student', '123456', "SELECT * FROM thannhan WHERE nhansu_id='$nhansu_id'");

?>
<body>
	<div class="container">
		<h1 class="text-center">Thêm mới thân nhân</h1>
		<form method="POST" action="./addthannhan.php" enctype="multipart/form-data">
			<input name="nhansu_id" type="text" class="form-control" value="<?= $nhansu_id ?>" hidden>
			<fieldset class="form-group">
				<label>Tên thân nhân</label>
				<input name="ten" type="text" class="form-control" placeholder="Tên thân nhân">
			</fieldset>
			<fieldset class="form-group">
				<label>Quan hệ</label>
				<input name="quanhe" type="text" class="form-control" placeholder="Quan hệ">
			</fieldset>
			<fieldset class="form-group">
				<label>Điện thoại</label>
				<input name="dienthoai" type="number" class="form-control" placeholder="Điện thoại">
			</fieldset>
			<button type="submit" class="btn btn-success form-control">Thêm thân nhân</button>
		</form>
	</div>
	<br>
	<div class="container">
		<?php foreach ($nhanSu as $value): ?>
			<h1 class="text-center">Danh sách thân nhân của <?= $value['hovaten'] ?></h1>
		<?php endforeach ?>
		
		<table class="table table-hover mt-2" style="width: 98%!important; margin: auto;">
			<thead class="thead-dark">
				<tr>
					<th>STT</th>
					<th>Quan hệ</th>
					<th>Tên</th>
					<th>Điện thoại</th>
				</tr>
			</thead>
			<tbody id="search-container">
				<?php $stt = 1; ?>
				<?php foreach ($allThanNhan as $value): ?>
					<tr>
						<td><?= $stt ?></td>
						<td><?= $value['quanhe'] ?></td>
						<td><?= $value['ten'] ?></td>
						<td><?= $value['dienthoai'] ?></td>
					</tr>
					<?php $stt++; ?>
				<?php endforeach ?>
			</tbody>
		</table>

		<a href="./index.php" class="btn btn-success float-right">Thoát</a>
	</div>
</body>
</html>