<?php  
	session_start();
	include('connect.php');
	if(!isset($_SESSION['username']))
	{
		header("location:login.php");
	} 
	if(!empty($_POST['submit']))
	{
		if(isset($_POST['hocsinh_id'])&&isset($_POST['namhoc'])&&isset($_POST['nhanxetchung'])&&isset($_POST['uudiem'])&&isset($_POST['cankhacphuc']))
		{
			$hocsinh_id = $_POST['hocsinh_id'];
			$namhoc = $_POST['namhoc'];
			$nhanxetchung = $_POST['nhanxetchung'];
			$uudiem = $_POST['uudiem'];
			$cankhacphuc = $_POST['cankhacphuc'];
			$sql = "INSERT INTO tongketnam (hocsinh_id,namhoc,nhanxetchung,uudiem,cankhacphuc) VALUES('$hocsinh_id','$namhoc','$nhanxetchung','$uudiem','$cankhacphuc')";
			$stmt = $conn->prepare($sql);
			$query = $stmt->execute();
			if($query)
			{
				header("location:list.php");
			}
			else
			{
				echo "Them that bai, vui long thu lai!";
			}
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Danh Sách Các Học Sinh-77564</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<body>
	<header>Danh Sách Các Học Sinh</header>
	<content>
		<div class="container">
			<ul class="nav">
				<li class="nav-item">
					<a class="nav-link" href="index.php">Trang Chủ</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="list.php">Danh Sách Học Sinh</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="assets/cau1.PNG">Ảnh Câu 1</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="logout.php">Đăng Xuất</a>
				</li>
			</ul>

			<form method="post">
				<fieldset class="form-group">
					<label for="formGroupExampleInput" class="text-nx">ID Học Sinh</label>
					<input type="text" class="form-control" name="hocsinh_id" placeholder="Nhập ID học sinh">
				</fieldset>
				<fieldset class="form-group">
					<label for="formGroupExampleInput" class="text-nx">Năm Học</label>
					<input type="text" class="form-control" name="namhoc" placeholder="Nhập năm học">
				</fieldset>
				<fieldset class="form-group">
					<label for="formGroupExampleInput2" class="text-nx">Nhận Xét Chung</label>
					<input type="text" class="form-control" name="nhanxetchung" placeholder="Nhập nhận xét chung">
				</fieldset>
				<fieldset class="form-group">
					<label for="formGroupExampleInput2" class="text-nx">Ưu Điểm</label>
					<input type="text" class="form-control" name="uudiem" placeholder="Nhập ưu điểm">
				</fieldset>
				<fieldset class="form-group">
					<label for="formGroupExampleInput2" class="text-nx">Khuyết Điểm</label>
					<input type="text" class="form-control" name="cankhacphuc" placeholder="Nhập khuyết điểm">
				</fieldset>
				<fieldset class="form-group">
					<input type="submit" class="form-control btn-nx" name="submit"  value="Lưu">
				</fieldset>
			</form>
		</div>
	</content>
	<footer>Hồ Thị Thu Thủy - 85107 - CNT60ĐH</footer>
</body>
</html>