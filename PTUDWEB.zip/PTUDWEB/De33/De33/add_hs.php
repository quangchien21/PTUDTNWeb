<?php  
	session_start();
	include('connect.php');
	if(!isset($_SESSION['username']))
	{
		header("location:login.php");
	}
	if (!empty($_POST['submit'])) 
	{
	 	if(isset($_POST['id'])&&isset($_POST['trangthai'])&&isset($_POST['lop_id'])&&isset($_POST['hovaten'])&&isset($_POST['ngaysinh'])&&isset($_POST['mota']))
		{
			$id = $_POST['id'];
			$trangthai = $_POST['trangthai'];
			$lop_id = $_POST['lop_id'];
			$hovaten = $_POST['hovaten'];
			$ngaysinh = $_POST['ngaysinh'];
			$mota = $_POST['mota'];
			$sql = "INSERT INTO tongketnam (hocsinh_id,namhoc,nhanxetchung,uudiem,cankhacphuc) VALUES('$hocsinh_id','$namhoc','$nhanxetchung','$uudiem','$cankhacphuc')";
			$stmt = $conn->prepare($sql);
			$query = $stmt->execute();
			if($query)
			{
				header("location:list.php");
			}
			else
			{
				echo "Them that bai, vui long thu lai!";
			}
		}
	} 
?>

<!DOCTYPE html>
<html>
<head>
	<title>Thêm học sinh</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js"></script>
	<link rel="stylesheet" type="text/css" href="assets/style.css">
</head>
<body>
	<header>Thêm học sinh</header>
	<content>
		<div class="container">
			<ul class="nav">
				<li class="nav-item">
					<a class="nav-link" href="index.php">Trang Chủ</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="list.php">Danh Sách Học Sinh</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="assets/cau1.PNG">Ảnh Câu 1</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="logout.php">Đăng Xuất</a>
				</li>
				<li class="nav-item">
						Xin Chào <?php echo($_SESSION['username']) ?>
						<br>
						Đăng nhập vào lúc <?php echo date("d/m/Y h:i:s") ?>
					</li>
			</ul>
		</div>

		<form>
			<fieldset class="form-group">
				<label for="formGroupExampleInput">ID</label>
				<input type="text" class="form-control" name="id" placeholder="Nhập id">
			</fieldset>
			<fieldset class="form-group">
				<label for="formGroupExampleInput">Trạng thái</label>
				<input type="text" class="form-control" name="trangthai" placeholder="Nhập trạng thái">
			</fieldset>
			<fieldset class="form-group">
				<label for="formGroupExampleInput">Mã lớp</label>
				<select class="form-control" name="lop_id" placeholder="Nhập mã lớp">
						<?php foreach ($result as $items): ?>
							<option value="<?php echo $items['idnv']; ?>"><?php echo $items['hovaten']; ?></option>
						<?php endforeach ?>
					</select>
			</fieldset>
			<fieldset class="form-group">
				<label for="formGroupExampleInput">Họ và tên</label>
				<input type="text" class="form-control" name="hovaten" placeholder="Nhập họ và tên">
			</fieldset>
			<fieldset class="form-group">
				<label for="formGroupExampleInput">Ngày sinh</label>
				<input type="date" class="form-control" name="ngaysinh" placeholder="Nhập ngày sinh">
			</fieldset>
			<fieldset class="form-group">
				<label for="formGroupExampleInput">Mô tả</label>
				<input type="text" class="form-control" name="mota" placeholder="Nhập mô tả">
			</fieldset>
			<fieldset class="form-group">
				<input type="submit" class="form-control" name="submit" value="Lưu">
			</fieldset>
		</form>
	</content>
	<footer>Hồ Thị Thu Thủy - 85107 - CNT60ĐH</footer>
</body>
</html>