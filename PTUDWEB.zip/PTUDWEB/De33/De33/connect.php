<?php  
	$conn = new PDO('mysql:host=localhost;dbname=thcs','student','123456');
?>